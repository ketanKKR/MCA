class Student2 {
    String name;
    int age;

    // Default constructor
    public Student2() {
        name = "Unknown";
        age = 0;
    }

    // Parameterized constructor
    public Student2(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Copy constructor
    public Student2(Student2 otherStudent) {
        this(otherStudent.name, otherStudent.age); // Jump to parameterized constructor
        // Additional initialization logic for copy constructor
    }


    // Initializer block
    {
        System.out.println("Initializer Block Called");
    }

    // Static block
    static {
        System.out.println("Static Block Called");
    }

    // Method to display details
    void displayDetails() {
        System.out.println("Student Name: " + name);
        System.out.println("Student Age: " + age);
    }
}

class Stestp1 {
    public static void main(String[] args) {
        Student2 s1 = new Student2(); // Default constructor
        Student2 s2 = new Student2("Alice", 20); // Parameterized constructor
        Student2 s3 = new Student2(s2); // Copy constructor

        System.out.println("Details for Student 1:");
        s1.displayDetails();

        System.out.println("\nDetails for Student 2:");
        s2.displayDetails();

        System.out.println("\nDetails for Student 3 (Copy of Student 2):");
        s3.displayDetails();
    }
}

