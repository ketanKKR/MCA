import java.io.*;

public class MergeFilesCharacterByCharacter {
    public static void main(String[] args) {
        try (FileReader reader1 = new FileReader("file1.txt");
             FileReader reader2 = new FileReader("file2.txt");
             FileWriter writer = new FileWriter("merged_character.txt")) {

            int character;
            while ((character = reader1.read()) != -1) {
                writer.write(character);
            }

            while ((character = reader2.read()) != -1) {
                writer.write(character);
            }

            System.out.println("Files merged character by character successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
