import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CopyFileWordByWord {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(new FileReader("source.txt"));
             FileWriter writer = new FileWriter("destination_word.txt")) {

            while (scanner.hasNext()) {
                String word = scanner.next();
                writer.write(word + " ");
            }
            System.out.println("File copied word by word successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
