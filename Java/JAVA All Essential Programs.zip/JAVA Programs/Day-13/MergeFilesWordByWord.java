import java.io.*;
import java.util.Scanner;

public class MergeFilesWordByWord {
    public static void main(String[] args) {
        try (Scanner scanner1 = new Scanner(new FileReader("file1.txt"));
             Scanner scanner2 = new Scanner(new FileReader("file2.txt"));
             FileWriter writer = new FileWriter("merged_word.txt")) {

            while (scanner1.hasNext()) {
                String word = scanner1.next();
                writer.write(word + " ");
            }

            while (scanner2.hasNext()) {
                String word = scanner2.next();
                writer.write(word + " ");
            }

            System.out.println("Files merged word by word successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
