import java.io.*;

public class MergeFilesLineByLine {
    public static void main(String[] args) {
        try (BufferedReader reader1 = new BufferedReader(new FileReader("file1.txt"));
             BufferedReader reader2 = new BufferedReader(new FileReader("file2.txt"));
             FileWriter writer = new FileWriter("merged_line.txt")) {

            String line;
            while ((line = reader1.readLine()) != null) {
                writer.write(line + "\n");
            }

            while ((line = reader2.readLine()) != null) {
                writer.write(line + "\n");
            }

            System.out.println("Files merged line by line successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
