class Emp {
    int id;
    String name;
    int age;


    public Emp() {
        this(0, "Unknown", 0);
    }

    
    public Emp(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    
    public void getDetails() {
        
    }

    
    public void showDetails() {
        System.out.println("Employee ID: " + id);
        System.out.println("Employee Name: " + name);
        System.out.println("Employee Age: " + age);
    }
}

class PartTimeEmp extends Emp {
    int numberOfHours;
    double ratePerHour;

    
    public PartTimeEmp() {
        super(); 
        this.numberOfHours = 0;
        this.ratePerHour = 0.0;
    }

    
    public PartTimeEmp(int id, String name, int age, int numberOfHours, double ratePerHour) {
        super(id, name, age); 
        this.numberOfHours = numberOfHours;
        this.ratePerHour = ratePerHour;
    }

    
    public void showDetails() {
        super.showDetails();
        System.out.println("Number of Hours: " + numberOfHours);
        System.out.println("Rate per Hour: " + ratePerHour);
    }
}

class FullTimeEmp extends Emp {
    double basicPay;
    double DA;

    
    public FullTimeEmp() {
        super(); // Call the default constructor of the base class
        this.basicPay = 0.0;
        this.DA = 0.0;
    }

    
    public FullTimeEmp(int id, String name, int age, double basicPay, double DA) {
        super(id, name, age); // Call the parameterized constructor of the base class
        this.basicPay = basicPay;
        this.DA = DA;
    }

    
    public void showDetails() {
        super.showDetails();
        System.out.println("Basic Pay: " + basicPay);
        System.out.println("Dearness Allowance (DA): " + DA);
    }
}

class EmpTest {
    public static void main(String[] args) {
        PartTimeEmp partTimeEmp = new PartTimeEmp(101, "John", 25, 20, 15.0);
        
        
        FullTimeEmp fullTimeEmp = new FullTimeEmp(102, "Alice", 30, 50000.0, 2000.0);

        
        System.out.println("Details of PartTimeEmp:");
        partTimeEmp.showDetails();
        System.out.println();

        System.out.println("Details of FullTimeEmp:");
        fullTimeEmp.showDetails();
    }
}
