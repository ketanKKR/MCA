class Emp {
    int id;
    String name;
    int age;

    
    public Emp() {
        this.id = 0;
        this.name = "";
        this.age = 0;
    }

  
    public Emp(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    
    public String getDetails() {
        return "ID: " + id + ", Name: " + name + ", Age: " + age;
    }

   
    public void showDetails() {
        System.out.println(getDetails());
    }
}


class PartTimeEmp extends Emp {
    int numberOfHours;
    double ratePerHour;

    public PartTimeEmp() {
        super();
        this.numberOfHours = 0;
        this.ratePerHour = 0.0;
    }

    public PartTimeEmp(int id, String name, int age, int numberOfHours, double ratePerHour) {
        super(id, name, age);
        this.numberOfHours = numberOfHours;
        this.ratePerHour = ratePerHour;
    }

    public String getDetails() {
        return super.getDetails() + ", Number of Hours: " + numberOfHours + ", Rate per Hour: " + ratePerHour;
    }
}

class FullTimeEmp extends Emp {
    double basicPay;
    double DA;

    public FullTimeEmp() {
        super();
        this.basicPay = 0.0;
        this.DA = 0.0;
    }

    public FullTimeEmp(int id, String name, int age, double basicPay, double DA) {
        super(id, name, age);
        this.basicPay = basicPay;
        this.DA = DA;
    }

    public String getDetails() {
        return super.getDetails() + ", Basic Pay: " + basicPay + ", DA: " + DA;
    }
}

public class Main {
    public static void main(String[] args) {
       
        PartTimeEmp partTimeEmp = new PartTimeEmp(101, "John", 25, 20, 15.5);
        
        FullTimeEmp fullTimeEmp = new FullTimeEmp(102, "Alice", 30, 50000, 10000);

        
        System.out.println("Details of Part Time Employee:");
        System.out.println(partTimeEmp.getDetails());

        
        System.out.println("\nDetails of Full Time Employee:");
        System.out.println(fullTimeEmp.getDetails());

        // Polymorphism example
        Emp emp1 = new PartTimeEmp(103, "Bob", 22, 15, 12.5);
        Emp emp2 = new FullTimeEmp(104, "Eva", 28, 60000, 12000);

        System.out.println("\nPolymorphism Example:");
        System.out.println("Details of Employee 1:");
        emp1.showDetails();
        System.out.println("\nDetails of Employee 2:");
        emp2.showDetails();
    }
}
