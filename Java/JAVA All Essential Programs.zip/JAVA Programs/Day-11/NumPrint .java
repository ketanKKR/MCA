class NumPrint implements Runnable {
    private final int start;
    private final int end;

    public NumPrint(int start, int end) {
        this.start = start;
        this.end = end;

    }

    public void run() {

        for (int i = start; i <= end; i++) {
            System.out.println(i);
        }

    }

    public static void main(String[] args) {
        int mid = 5000 / 2;
        NumPrint printer1 = new NumPrint(1, mid);
        NumPrint printer2 = new NumPrint(mid + 1, 5000);
        Thread thread1 = new Thread(printer1);
        Thread thread2 = new Thread(printer2);
        thread1.start();
        thread2.start();

        try {

            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("All numbers printed!");

    }

}
