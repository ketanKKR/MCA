class NumberPrinter extends Thread {
    private final int start;
    private final int end;

    public NumberPrinter(int start, int end) {
        this.start = start;
        this.end = end;

    }

    @Override

    public void run() {

        for (int i = start; i <= end; i++) {
            System.out.println(i);
        }

    }

    public static void main(String[] args) {
        int mid = 5000 / 2;
        NumberPrinter thread1 = new NumberPrinter(1, mid + 1);
        NumberPrinter thread2 = new NumberPrinter(mid + 2, 5000);
        thread1.start();
        thread2.start();
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();

        }

        System.out.println("All numbers printed!");

    }

}
