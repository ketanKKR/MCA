import java.util.ArrayList;
import java.util.List;

class Student {
    int id;
    String name;
    int age;

    public Student(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public String toString() {
        return "Student[id=" + id + ", name=" + name + ", age=" + age + "]";
    }
}

class Main {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();
        students.add(new Student(1, "Hit Soliya", 21));
        students.add(new Student(2, "Mohit Libachiya", 20));
        students.add(new Student(3, "Wagha Kiran", 23));
        students.add(new Student(4, "Gupta Vivek", 20));
        students.add(new Student(5, "Patel Bhutik", 22));
        for (Student student : students) {
            System.out.println(student);
        }
    }
}
