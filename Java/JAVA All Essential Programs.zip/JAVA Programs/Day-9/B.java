import java.util.Stack;
class Student {
 int id;
 String name;
 int age;
 public Student(int id, String name, int age) {
 this.id = id;
 this.name = name;
 this.age = age;
 }
 public String toString() {
 return "Student[id=" + id + ", name=" + name + ", age=" + age + "]";
 }
}
class B {
 public static void main(String[] args) {
 Stack<Student> students = new Stack<>();
 students.push(new Student(1, "Hit Soliya", 21));
 students.push(new Student(2, "Parmar Maulik", 20));
 students.push(new Student(3, "Wagh Kiran", 23));
 students.push(new Student(4, "Gupta Vivek", 20));
 students.push(new Student(5, "Samir Prajapati", 22));
 System.out.println("Stack: ");
 for (Student student : students) {
 System.out.println(student);
 }
 System.out.println("Popped: " + students.pop());
 System.out.println("Stack after popping: ");
 for (Student student : students) {
 System.out.println(student);
 }
 }
}
