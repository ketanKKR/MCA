import java.util.Vector;

class Student {
    int id;
    String name;
    int age;

    public Student(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public String toString() {
        return "Student[id =" + id + ", name = " + name + ", age = " + age + "]";
    }
}

class studentInfo {
    public static void main(String[] args) {
        Vector<Student> students = new Vector<>();
        students.add(new Student(1, "Hit Soliya", 21));
        students.add(new Student(2, "Gupta Vivek", 20));
        students.add(new Student(3, "Wagh Kiran", 23));
        students.add(new Student(4, "Ketan Rathod", 21));
        students.add(new Student(5, "Patel Bhutik", 20));

        System.out.println("Vector: ");
        for (Student student : students) {
            System.out.println(student);
        }
    }
}
