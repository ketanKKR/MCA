class AdditionWithForLoop {
    public static void main(String[] args) {
        int startNumber = 3;
        int endNumber = 10;
        int sum = 0;
        for (int i = startNumber; i <= endNumber; i++) {
            sum += i;
        }

             System.out.println("The sum of numbers between " + startNumber + " and " + endNumber + " is: " + sum);
    }
}
