import java.util.*;

class getSdetail {
    String name;
    int age;

    // Method to get details from the user
    void getDetails() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter student name: ");
        name = sc.nextLine();

        System.out.print("Enter student age: ");
        age = sc.nextInt();

        // Consume the newline character left by nextInt()
        //scanner.nextLine();12
    }

    // Method to display details
    void displayDetails() {
        System.out.println("Student Name: " + name);
        System.out.println("Student Age: " + age);
    }
}

class Sgd {
    public static void main(String[] args) {
        getSdetail student1 = new getSdetail();
        getSdetail student2 = new getSdetail();
        getSdetail student3 = new getSdetail();


        System.out.println("Enter details for Student 1:");
        student1.getDetails();

        System.out.println("\nEnter details for Student 2:");
        student2.getDetails();

        System.out.println("\nEnter details for Student 3:");
        student3.getDetails();


        System.out.println("\nDetails for Student 1:");
        student1.displayDetails();

        System.out.println("\nDetails for Student 2:");
        student2.displayDetails();

        System.out.println("\nDetails for Student 3:");
        student3.displayDetails();
    }
}
