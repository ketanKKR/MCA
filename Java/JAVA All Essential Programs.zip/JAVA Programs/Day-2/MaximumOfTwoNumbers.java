class MaximumOfTwoNumbers {
    public static void main(String[] args) {
        
        int num1 = 15;
        int num2 = 8;

        
        int maximum = (num1 > num2) ? num1 : num2;

        System.out.println("The maximum of " + num1 + " and " + num2 + " is: " + maximum);
    }
}
