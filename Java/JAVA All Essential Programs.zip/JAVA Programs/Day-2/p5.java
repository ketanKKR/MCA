class p5 {
    public static void main(String[] args) {
        // Define two numbers
        outer:
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (j == 1)
                    break outer;
                System.out.println(" value of j = " + j);
            }
        } // end of outer loop

    }
}
