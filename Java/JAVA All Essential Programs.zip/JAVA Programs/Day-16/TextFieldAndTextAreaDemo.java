import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TextFieldAndTextAreaDemo extends JFrame implements ActionListener {
    JTextField textField;
    JTextArea textArea;

    public TextFieldAndTextAreaDemo() {
        setTitle("TextField and TextArea Demo");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel to hold components
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Create a text field
        textField = new JTextField(20);
        textField.addActionListener(this); // Register ActionListener
        panel.add(textField, BorderLayout.NORTH);

        // Create a text area
        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Add panel to the frame
        add(panel);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Get the text from the text field and append it to the text area
        String text = textField.getText();
        textArea.append(text + "\n");

        // Clear the text field
        textField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TextFieldAndTextAreaDemo());
    }
}
