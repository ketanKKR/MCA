import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LayoutManagerDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Layout Manager Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // FlowLayout
        JPanel flowLayoutPanel = new JPanel(new FlowLayout());
        flowLayoutPanel.add(new JButton("Button 1"));
        flowLayoutPanel.add(new JButton("Button 2"));
        flowLayoutPanel.add(new JButton("Button 3"));
        frame.add(flowLayoutPanel, BorderLayout.NORTH);

        // BorderLayout
        JPanel borderLayoutPanel = new JPanel(new BorderLayout());
        borderLayoutPanel.add(new JButton("Button 4 (North)"), BorderLayout.NORTH);
        borderLayoutPanel.add(new JButton("Button 5 (Center)"), BorderLayout.CENTER);
        borderLayoutPanel.add(new JButton("Button 6 (South)"), BorderLayout.SOUTH);
        frame.add(borderLayoutPanel, BorderLayout.CENTER);

        // GridLayout
        JPanel gridLayoutPanel = new JPanel(new GridLayout(2, 3));
        gridLayoutPanel.add(new JButton("Button 7"));
        gridLayoutPanel.add(new JButton("Button 8"));
        gridLayoutPanel.add(new JButton("Button 9"));
        gridLayoutPanel.add(new JButton("Button 10"));
        gridLayoutPanel.add(new JButton("Button 11"));
        gridLayoutPanel.add(new JButton("Button 12"));
        frame.add(gridLayoutPanel, BorderLayout.SOUTH);

        // GridBagLayout
        JPanel gridBagLayoutPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(5, 5, 5, 5);
        gridBagLayoutPanel.add(new JButton("Button 13"), gbc);
        gbc.gridx = 1;
        gridBagLayoutPanel.add(new JButton("Button 14"), gbc);
        gbc.gridy = 1;
        gbc.gridx = 0;
        gridBagLayoutPanel.add(new JButton("Button 15"), gbc);
        gbc.gridx = 1;
        gridBagLayoutPanel.add(new JButton("Button 16"), gbc);
        frame.add(gridBagLayoutPanel, BorderLayout.EAST);

        // CardLayout
        JPanel cardLayoutPanel = new JPanel(new CardLayout());
        JButton card1 = new JButton("Card 1");
        JButton card2 = new JButton("Card 2");
        JButton card3 = new JButton("Card 3");
        cardLayoutPanel.add(card1, "card1");
        cardLayoutPanel.add(card2, "card2");
        cardLayoutPanel.add(card3, "card3");

        Timer timer = new Timer(1000, new ActionListener() {
            int count = 1;
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout layout = (CardLayout) cardLayoutPanel.getLayout();
                layout.show(cardLayoutPanel, "card" + (count % 3 + 1));
                count++;
            }
        });
        timer.start();
        frame.add(cardLayoutPanel, BorderLayout.WEST);

        frame.setVisible(true);
    }
}
