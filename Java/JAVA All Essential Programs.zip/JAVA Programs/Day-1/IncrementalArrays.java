//4.	Create following arrays and assign incremental values starting from 1 to each element. 
    //1.	Array with 2 rows and 3 columns. 
    //2.	Array with 2 rows. First row has 3 cells, and second row has 2 cells.
            //Print the content of both the arrays. 

class IncrementalArrays {
    public static void main(String[] args) {
        
        int[][] array1 = new int[2][3];
        fillArray(array1);

        
        int[][] array2 = new int[2][];
        array2[0] = new int[3];
        array2[1] = new int[2];
        fillArray(array2);

        
        System.out.println("Array 1:");
        printArray(array1);

        System.out.println("\nArray 2:");
        printArray(array2);
    }

    
    private static void fillArray(int[][] array) {
        int value = 1;
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                array[i][j] = value++;
            }
        }
    }

    
    private static void printArray(int[][] array) {
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                System.out.print(array[i][j] + " ");
            }
            System.out.println();
        }
    }
}
