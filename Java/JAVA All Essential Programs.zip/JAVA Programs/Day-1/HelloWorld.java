//2.	Write the “Hello World” - first Java Program. Compile and execute it.
class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}