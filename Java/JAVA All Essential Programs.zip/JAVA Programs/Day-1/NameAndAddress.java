//6.	Write a program to print your name and address.
class NameAndAddress {
    public static void main(String[] args) {
        // Print name and address
        System.out.println("Name: Your Name");
        System.out.println("Address: Anida, Amreli, Gujrat");
    }
}
