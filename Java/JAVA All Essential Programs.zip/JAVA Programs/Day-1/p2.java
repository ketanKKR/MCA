
//3.	Write comments (Author, date, objective of the program, main function) in the above program. 
/*
 * Author: Hit Soliya
 * Date: January 22, 2024
 * Objective: This program assingment a simple "Hello World" output in Java.
 * 
 * Explanation:
 * The HelloWorld class contains the main method, which is the entry point of the program.
 * The main method prints the "Hello, World!" message to the console using System.out.println.
 */
class p2 {
    
    /**
     * The main method is the entry point of the program.
     * args Command-line arguments (not used in this program).
     */
    public static void main(String[] args) {
        // Print the "Hello, World!" message to the console
        System.out.println("Author : Hit Soliya");
        System.out.println("Date : January 22,2024");
        System.out.println("Objective : This program assingment a simple");
    }
}
