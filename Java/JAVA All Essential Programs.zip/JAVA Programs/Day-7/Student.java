
import java.util.Objects;
class Student {
 private int id;
 private String name;
 private int age;
 
 public Student(int id, String name, int age) {
 this.id = id;
 this.name = name;
 this.age = age;
 }
 
 
 public String toString() {
 return "Student{" +
 "id=" + id +
 ", name='" + name + '\'' +
 ", age=" + age +
 '}';
 }
 
 
 public boolean equals(Object obj) {
 if (this == obj) {
 return true;
 }
 if (obj == null || getClass() != obj.getClass()) {
 return false;
 }
 Student student = (Student) obj;
 return id == student.id &&
 age == student.age &&
 Objects.equals(name, student.name);
 }
 public static void main(String[] args) {
 
 Student student1 = new Student(1, "John", 20);
 Student student2 = new Student(2, "Jane", 22);
 Student student3 = new Student(1, "John", 20);
 
 System.out.println("Student 1: " + student1);
 System.out.println("Student 2: " + student2);
 System.out.println("Student 3: " + student3);

 System.out.println("student1.equals(student2): " + student1.equals(student2));
 System.out.println("student1.equals(student3): " + student1.equals(student3));
 }
}
