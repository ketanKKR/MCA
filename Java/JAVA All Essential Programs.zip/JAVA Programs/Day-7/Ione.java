interface Ione{
    int a=10;
    }
    interface Itwo{
    int b=20;
    }
    interface Ithree extends Ione,Itwo {
    int c=30;
    }
    class Test implements Ithree{
    public static void main(String[] args){
    Test t1=new Test();
    System.out.println("a: " + t1.a);
     System.out.println("b: " + t1.b);
     System.out.println("c: " + t1.c);
    }
    }
    