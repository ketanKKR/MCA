import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class StudentManagement {

    private static final String FILE_NAME = "students.dat";

    public static void main(String[] args) throws IOException {
        List<Student> students = new ArrayList<>();

        students.add(new Student(1, "Mohit", 22));
        students.add(new Student(2, "Hit", 23));
        students.add(new Student(3, "Ketan", 24));
        students.add(new Student(4, "Maulik", 25));
        students.add(new Student(5, "Vivek", 26));

        writeStudentsToFile(students);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter student ID (or 0 to exit): ");
            int id = scanner.nextInt();

            if (id == 0) {
                break;
            }

            Student foundStudent = findStudentById(students, id);
            if (foundStudent != null) {
                System.out.println("Student Information:");
                System.out.println("ID: " + foundStudent.getId());
                System.out.println("Name: " + foundStudent.getName());
                System.out.println("Age: " + foundStudent.getAge());
            } else {
                System.out.println("Student with ID " + id + " not found.");
            }
        }
    }

    static void writeStudentsToFile(List<Student> students) throws IOException {
        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            objectOutputStream.writeObject(students);
        }
    }

    static List<Student> readStudentsFromFile() throws IOException, ClassNotFoundException {
        try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            return (List<Student>) objectInputStream.readObject();
        }
    }

    static Student findStudentById(List<Student> students, int id) {
        return students.stream()
                .filter(student -> student.getId() == id)
                .findFirst()
                .orElse(null);
    }
}

class Student implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String name;
    private int age;

    Student(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    int getId() {
        return id;
    }

    String getName() {
        return name;
    }

    int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Student [id=" + id + ", name=" + name + ", age=" + age + "]";
    }
}
