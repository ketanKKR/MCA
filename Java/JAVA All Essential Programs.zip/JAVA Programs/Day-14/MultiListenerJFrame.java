import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class MultiListenerJFrame extends JFrame
        implements MouseListener, MouseMotionListener, KeyListener, WindowListener {

    private JButton clickMeButton;

    public MultiListenerJFrame() {
        super("Multi-Listener JFrame");

        clickMeButton = new JButton("Click Me");
        clickMeButton.addActionListener(e -> System.out.println("Button clicked! (ActionListener)"));
        add(clickMeButton, BorderLayout.CENTER);

        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        this.addKeyListener(this);
        this.addWindowListener(this);

        pack();
        setVisible(true);
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("Mouse clicked at (" + e.getX() + ", " + e.getY() + "). (MouseListener)");
    }
    @Override
    public void mousePressed(MouseEvent e) {
        System.out.println("Mouse button pressed. (MouseListener)");
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        System.out.println("Mouse button released. (MouseListener)");
    }
    @Override
    public void mouseEntered(MouseEvent e) {
        System.out.println("Mouse entered the frame. (MouseListener)");
    }
    @Override
    public void mouseExited(MouseEvent e) {
        System.out.println("Mouse exited the frame. (MouseListener)");
    }
    @Override
    public void mouseDragged(MouseEvent e) {
        System.out.println("Mouse dragged at (" + e.getX() + ", " + e.getY() + "). (MouseMotionListener)");
    }
    @Override
    public void mouseMoved(MouseEvent e) {
        System.out.println("Mouse moved at (" + e.getX() + ", " + e.getY() + "). (MouseMotionListener)");
    }
    @Override
    public void keyTyped(KeyEvent e) {
        System.out.println("Key typed: " + e.getKeyChar() + ". (KeyListener)");
    }
    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("Key pressed: " + e.getKeyChar() + ". (KeyListener)");
    }
    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println("Key released: " + e.getKeyChar() + ". (KeyListener)");
    }
    @Override
    public void windowOpened(WindowEvent e) {
        System.out.println("Window opened. (WindowListener)");
    }
    @Override
    public void windowClosing(WindowEvent e) {
        System.out.println("Window closing. (WindowListener)");
    }
    @Override
    public void windowClosed(WindowEvent e) {
        System.out.println("Window closed. (WindowListener)");
    }
    @Override
    public void windowIconified(WindowEvent e) {
        System.out.println("Window minimized. (WindowListener)");
    }
    @Override
    public void windowDeiconified(WindowEvent e) {
        System.out.println("Window maximized. (WindowListener)");
    }
    @Override
    public void windowActivated(WindowEvent e) {
        System.out.println("Window activated. (WindowListener)");
    }
    @Override
    public void windowDeactivated(WindowEvent e) {
        System.out.println("Window deactivated. (WindowListener)");
    }
    public static void main(String[] args) {
        new MultiListenerJFrame();
    }
}
