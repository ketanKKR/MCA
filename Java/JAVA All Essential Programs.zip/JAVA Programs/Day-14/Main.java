import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String name;
    private int age;

    // Constructor
    public Student(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}

public class Main {
    public static void main(String[] args) {
        // Create a list of students
        List<Student> students = new ArrayList<>();
        students.add(new Student(1, "Alice", 20));
        students.add(new Student(2, "Bob", 21));
        students.add(new Student(3, "Charlie", 22));
        students.add(new Student(4, "David", 23));
        students.add(new Student(5, "Eve", 24));

        // Write objects to file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("students.dat"))) {
            for (Student student : students) {
                oos.writeObject(student);
            }
            System.out.println("Objects written to file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Retrieve information of a specific student by ID
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("students.dat"));
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter the ID of the student: ");
            int id = scanner.nextInt();
            boolean found = false;

            while (true) {
                try {
                    Student student = (Student) ois.readObject();
                    if (student.getId() == id) {
                        System.out.println("Student found:");
                        System.out.println("ID: " + student.getId());
                        System.out.println("Name: " + student.getName());
                        System.out.println("Age: " + student.getAge());
                        found = true;
                        break;
                    }
                } catch (EOFException e) {
                    break;
                }
            }

            if (!found) {
                System.out.println("Student with ID " + id + " not found.");
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
