class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}

class Student {
    private int id;
    private String name;
    private int age;

    public Student(int id, String name, int age) throws InvalidAgeException {
        this.id = id;
        this.name = name;
        if (age < 20) {
            throw new InvalidAgeException("Age should be at least 20 years.");
        } else {
            this.age = age;
        }
    }

    public static void main(String[] args) {
        try {
            Student student = new Student(1, "John Doe", 17);
        } catch (InvalidAgeException e) {
            System.out.println("An InvalidAgeException occurred: " + e.getMessage());
        }
    }
}
