import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentInformationApp extends JFrame implements ActionListener {
    JTextField idField, nameField, ageField, emailField, semField;

    public StudentInformationApp() {
        setTitle("Student Information App");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2, 5, 5));

        panel.add(new JLabel("ID:"));
        idField = new JTextField();
        panel.add(idField);

        panel.add(new JLabel("Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Age:"));
        ageField = new JTextField();
        panel.add(ageField);

        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);

        panel.add(new JLabel("Semester:"));
        semField = new JTextField();
        panel.add(semField);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(this);
        panel.add(submitButton);

        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(this);
        panel.add(clearButton);

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Submit")) {
            if (validateEmail()) {
                String id = idField.getText();
                String name = nameField.getText();
                String age = ageField.getText();
                String email = emailField.getText();
                String sem = semField.getText();

                String message = "Student Information:\n"
                        + "ID: " + id + "\n"
                        + "Name: " + name + "\n"
                        + "Age: " + age + "\n"
                        + "Email: " + email + "\n"
                        + "Semester: " + sem;

                JOptionPane.showMessageDialog(this, message, "Student Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid email address!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getActionCommand().equals("Clear")) {
            clearFields();
        }
    }

    private boolean validateEmail() {
        String email = emailField.getText();
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        ageField.setText("");
        emailField.setText("");
        semField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StudentInformationApp::new);
    }
}
