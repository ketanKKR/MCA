import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentInformationAppWithMenus extends JFrame implements ActionListener {
    JTextField idField, nameField, ageField, emailField, semField;

    public StudentInformationAppWithMenus() {
        setTitle("Student Information App");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu operationsMenu = new JMenu("Operations");
        menuBar.add(operationsMenu);

        JMenuItem newMenuItem = new JMenuItem("New");
        newMenuItem.addActionListener(this);
        operationsMenu.add(newMenuItem);

        JMenuItem closeMenuItem = new JMenuItem("Close");
        closeMenuItem.addActionListener(this);
        operationsMenu.add(closeMenuItem);

        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(this);
        operationsMenu.add(exitMenuItem);

        JMenu helpMenu = new JMenu("Help");
        menuBar.add(helpMenu);

        JMenuItem aboutMenuItem = new JMenuItem("About Application");
        aboutMenuItem.addActionListener(this);
        helpMenu.add(aboutMenuItem);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2, 5, 5));

        panel.add(new JLabel("ID:"));
        idField = new JTextField();
        panel.add(idField);

        panel.add(new JLabel("Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Age:"));
        ageField = new JTextField();
        panel.add(ageField);

        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);

        panel.add(new JLabel("Semester:"));
        semField = new JTextField();
        panel.add(semField);

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        switch (command) {
            case "New":
                clearFields();
                break;
            case "Close":
                dispose();
                break;
            case "Exit":
                System.exit(0);
                break;
            case "About Application":
                JOptionPane.showMessageDialog(this, "Student Information App\nVersion 1.0\nDeveloped by Your Name",
                        "About", JOptionPane.INFORMATION_MESSAGE);
                break;
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        ageField.setText("");
        emailField.setText("");
        semField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StudentInformationAppWithMenus::new);
    }
}
