class CountPrinter implements Runnable {
    private static final String currentCount = null;
    private static int count;

    public void run() {

        for (int i = 0; i < 5000; i++) {

            synchronized (CountPrinter.class) { 
                System.out.println(Thread.currentThread().getName() + ": " + currentCount);
                count++;
            }

        }

    }

    public static void main(String[] args) {
        CountPrinter printer = new CountPrinter();
        Thread thread1 = new Thread(printer);
        Thread thread2 = new Thread(printer);
        thread1.start();
        thread2.start();
        try {
            thread1.join();

            thread2.join();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final count: " + count);

    }

}
