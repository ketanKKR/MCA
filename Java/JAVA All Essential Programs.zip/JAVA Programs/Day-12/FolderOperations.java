import java.io.File;

class FolderOperations {
    public static void main(String[] args) {
        String folderName = "NewFolder";
        File folder = new File(folderName);

        // Create the folder
        boolean folderCreated = folder.mkdir();
        if (folderCreated) {
            System.out.println("Folder created successfully.");
        } else {
            System.out.println("Failed to create folder.");
            return;
        }

        // Rename the folder
        String newFolderName = "RenamedFolder";
        File newFolder = new File(newFolderName);
        boolean renamed = folder.renameTo(newFolder);
        if (renamed) {
            System.out.println("Folder renamed successfully.");
        } else {
            System.out.println("Failed to rename folder.");
            return;
        }

        // Delete the folder
        boolean deleted = newFolder.delete();
        if (deleted) {
            System.out.println("Folder deleted successfully.");
        } else {
            System.out.println("Failed to delete folder.");
        }
    }
}
