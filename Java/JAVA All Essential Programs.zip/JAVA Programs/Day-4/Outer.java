class Outer {
    int a; // Instance variable

    // Constructor to initialize 'a'
    Outer(int a) {
        this.a = a;
    }

    // Inner class
    class Inner {
        int b; // Inner class instance variable

        // Constructor to initialize 'b'
        Inner(int b) {
            this.b = b;
        }
    }

    public static void main(String[] args) {
        // Create an object of Outer class
        Outer outerObj = new Outer(10);

        // Create an object of Inner class
        Outer.Inner innerObj = outerObj.new Inner(20);

        // Accessing and printing values of 'a' and 'b'
        System.out.println("Value of 'a': " + outerObj.a);
        System.out.println("Value of 'b': " + innerObj.b);
    }
}
