class Calculator {
    // Method to add two integers
    int add(int num1, int num2) {
        return num1 + num2;
    }

    // Method to add two floats
    float add(float num1, float num2) {
        return num1 + num2;
    }
}

class CalculatorTest {
    public static void main(String[] args) {
        // Create a Calculator object
        Calculator calculator = new Calculator();

        // Test adding two integers
        int sumIntegers = calculator.add(5, 7);
        System.out.println("Sum of integers: " + sumIntegers);

        // Test adding two floats
        float sumFloats = calculator.add(3.5f, 2.8f);
        System.out.println("Sum of floats: " + sumFloats);
    }
}
