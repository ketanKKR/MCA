class Outer {
    int a; // Instance variable in the outer class

    // Constructor for the outer class
    public Outer(int a) {
        this.a = a;
    }

    // Inner class
    class Inner {
        int b; // Instance variable in the inner class

        // Constructor for the inner class
        public Inner(int b) {
            this.b = b;
        }
    }
}

class OuterInnerTest {
    public static void main(String[] args) {
        // Create an object of the outer class
        Outer outerObject = new Outer(5);

        // Create an object of the inner class using the outer class object
        Outer.Inner innerObject = outerObject.new Inner(10);

        // Print values of "a" and "b"
        System.out.println("Value of 'a': " + outerObject.a);
        System.out.println("Value of 'b': " + innerObject.b);
    }
}
