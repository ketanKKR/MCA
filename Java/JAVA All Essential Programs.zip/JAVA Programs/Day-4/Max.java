class Student {
    String name;
    int age;

    // Default constructor
    public Student() {
        // Default values
        this("Unknown", 0);
    }

    // Parameterized constructor
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Copy constructor
    public Student(Student otherStudent) {
        this(otherStudent.name, otherStudent.age);
    }

    // Method to display details
    void displayDetails() {
        System.out.println("Student Name: " + name);
        System.out.println("Student Age: " + age);
        System.out.println();
    }

    // Method to compare ages and print the name of the student with the highest age
    static void compareAges(Student student1, Student student2) {
        if (student1.age > student2.age) {
            System.out.println(student1.name + " has the highest age.");
        } else if (student1.age < student2.age) {
            System.out.println(student2.name + " has the highest age.");
        } else {
            System.out.println("Both students have the same age.");
        }
    }
}

class Max {
    public static void main(String[] args) {
        // Create two Student objects
        Student student1 = new Student("Alice", 22);
        Student student2 = new Student("Bob", 25);

        // Compare ages and print the name of the student with the highest age
        Student.compareAges(student1, student2);
    }
}
