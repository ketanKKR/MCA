class St
{
    String name;
    int age;

    // Default constructor
    public St()
    {
        // Default values
        this("Unknown", 0);
    }

    // Parameterized constructor
    public St(String name, int age)
    {
        this.name = name;
        this.age = age;
    }

    // Copy constructor
    public St(St otherStudent)
    {
        this(otherStudent.name, otherStudent.age);
    }

    // Method to display details
    void displayDetails()
    {
        System.out.println("Student Name: " + name);
        System.out.println("Student Age: " + age);
        System.out.println();
    }

    // Method to compare ages and return the Student object with the highest age
    static St compareAges(St student1, St student2)
    {
        return (student1.age > student2.age) ? student1 : student2;
    }
}

class StudentDeteile
{
    public static void main(String[] args) 
    {
        // Create two Student objects
        St student1 = new St("Alice", 22);
        St student2 = new St("Bob", 25);

        // Compare ages and get the student with the highest age
        St studentWithHighestAge = St.compareAges(student1, student2);

        // Print the name of the student with the highest age
        System.out.println("Student with the highest age: " + studentWithHighestAge.name);
    }
}

