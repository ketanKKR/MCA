class Std {
    String name;
    int age;
    static int studentCount = 0; // Static variable to store the number of objects created

    // Default constructor
    public Std() {
        // Default values
        this("Unknown", 0);
        studentCount++; // Increment count when a new object is created
    }

    // Parameterized constructor
    public Std(String name, int age) {
        this.name = name;
        this.age = age;
        studentCount++; // Increment count when a new object is created
    }

    // Copy constructor
    public Std(Std otherStudent) {
        this(otherStudent.name, otherStudent.age);
    }

    // Method to display details
    void displayDetails() {
        System.out.println("Student Name: " + name);
        System.out.println("Student Age: " + age);
        System.out.println();
    }

    // Static method to display the count of objects created
    static void displayStudentCount() {
        System.out.println("Number of Students: " + studentCount);
    }
}

public class studentcount {
    public static void main(String[] args) {
        // Create three Student objects
        Std student1 = new Std();
        Std student2 = new Std("Alice", 22);
        Std student3 = new Std(student2);

        // Display details for each student
        System.out.println("Details for Student 1:");
        student1.displayDetails();

        System.out.println("Details for Student 2:");
        student2.displayDetails();

        System.out.println("Details for Student 3 (Copy of Student 2):");
        student3.displayDetails();

        // Display the count of objects created
        Std.displayStudentCount();
    }
}
